// Main class for the poisonous plants problem
package com.example.poisonousplants;

class Stk {

    private int[] stkArr = null; // Array to store elements of the stack

    private static int[] stkMaxArr = null; // Static array to store maximum values of the stack

    private static int maxPointer = 0; // Pointer to the maximum value in the stkMaxArr array

    private int currentPointer = -1; // Pointer to the current element in the stack

    private int size = 0; // Size of the stack

    private int total = 0; // Variable to keep track of the total sum of elements in the stack

    public Stk(int size) {
        super();
        this.size = size;
        stkArr = new int[size];
    }

    public void push(int x) {
        currentPointer++;
        stkArr[currentPointer] = x; // Add the element to the stack array at the current pointer

        total = total + x; // Update the total sum of elements

    }

    public int getTotal() {
        return total; // Return the total sum of elements in the stack
    }

    public int pop() {
        int val = stkArr[currentPointer]; // Get the value at the current pointer
        stkArr[currentPointer] = 0; // Set the value at the current pointer to 0
        currentPointer--; // Decrement the current pointer

        total = total - val; // Update the total sum of elements

        return val; // Return the popped value

    }

    public int peep() {
        if (currentPointer > -1)
            return stkArr[currentPointer]; // Return the value at the current pointer if it is valid
        else
            return -99; // Return a default value (-99) if the current pointer is invalid
    }

    public int getCurrentPointer() {
        return currentPointer; // Return the current pointer
    }

    public int getSize() {
        return size; // Return the size of the stack
    }

    public int getMax() {
        return stkMaxArr[maxPointer]; // Return the maximum value in the stack
    }
}