// Main class for the poisonous plants problem
package com.example.poisonousplants;

import java.util.*;

public class plantsLife {

    // Main method to execute the program
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in); // Scanner for reading input
        int N = sc.nextInt(); // Read the number of plants

        int[] a = new int[N]; // Array to store the pesticide levels of each plant

        // Loop to read pesticide levels into array 'a'
        for (int i = 0; i < a.length; i++) {
            a[i] = sc.nextInt();
        }

        System.out.println(process(a)); // Call process method and print result
    }

    // Method to process the array and return the maximum number of days
    public static int process(int[] a) {

        Stk A = new Stk(a.length); // Creating an instance of plants class

        int max = 0; // Variable to store maximum number of days

        A.push(0); // Push first plant into the stack

        // Arrays to store nearest smaller element (k) and number of days (d)
        int[] k = new int[a.length];
        int[] d = new int[a.length];

        k[0] = -1; // Initialize first element of k as -1

        // Loop through plants to calculate days until each plant dies
        for (int i = 1; i < a.length; i++) {

            if (a[A.peep()] < a[i]) {
                // If the pesticide level of the current plant is greater than the previous plant,
                // it means the current plant will survive for 1 day
                k[i] = A.peep();

                d[i] = 1;

            } else if (a[A.peep()] == a[i]) {
                // If the pesticide level of the current plant is equal to the previous plant,
                // it means the current plant will have the same number of days as the previous plant
                k[i] = k[A.peep()];

                if (k[i] != -1)
                    d[i] = d[A.peep()] + 1;
                else
                    d[i] = d[A.peep()];

            } else if (a[A.peep()] > a[i]) {
                // If the pesticide level of the current plant is less than the previous plant,
                // we need to find the nearest smaller element and calculate the number of days accordingly
                while (A.getCurrentPointer() != -1 && a[A.peep()] > a[i]) {
                    A.pop();
                }
                if (A.getCurrentPointer() == -1) {
                    k[i] = -1;
                } else if (a[A.peep()] == a[i]) {

                    k[i] = k[A.peep()];
                    if (k[i] != -1) {

                        d[i] = getMax(d, k[i] + 1, i - 1) + 1;
                    } else
                        d[i] = d[A.peep()] + 1;

                } else {
                    k[i] = A.peep();

                    d[i] = getMax(d, k[i] + 1, i - 1) + 1;

                }

            }
            A.push(i);
            if (max < d[i])
                max = d[i];
        }

        return max;
    }

    // Method to get the maximum value in a subarray
    public static int getMax(int[] maxK, int start, int end) {

        int max = 0;
        for (int i = start; i <= end; i++) {
            int c = maxK[i];
            if (c > max)
                max = c;
        }
        return max;
    }

}