module com.example.poisonousplants {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.poisonousplants to javafx.fxml;
    exports com.example.poisonousplants;
}